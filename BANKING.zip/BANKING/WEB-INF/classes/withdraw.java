import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class withdraw extends HttpServlet{
    public void service(HttpServletRequest request,HttpServletResponse response) throws IOException,ServletException{

        PrintWriter out=response.getWriter();
        response.setContentType("text/html");

        String acc=request.getParameter("ACC");

        String amount=request.getParameter("AMOUNT");        
        try{
            Class.forName("oracle.jdbc.driver.OracleDriver");
            
            Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","sys as sysdba","anand");

            // PreparedStatement pst=con.prepareStatement("select accno from bank");
            Statement st=con.createStatement();

            ResultSet rs=st.executeQuery("select accno from bank");
            ResultSetMetaData rsmd=rs.getMetaData();

            int nc=rsmd.getColumnCount();

            while(rs.next()){
                    if(rs.getString(1).equals(acc))
                    {    
                        ResultSet ra=st.executeQuery("select amount from bank where accno="+acc);
                        ra.next();
                        response.sendRedirect("withdraw.jsp?ACC="+acc+"&BALANCE="+ra.getString(1)); }

                
            }

            response.sendRedirect("withdraw.jsp?ACC=*account doesnot exist");

        }

        catch(Exception e){
            System.out.println("404 ERROR FOUND"+e);
        }

    }
}