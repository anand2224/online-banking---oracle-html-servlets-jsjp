import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;

public class deposit1 extends HttpServlet{
    public void service(HttpServletRequest request,HttpServletResponse response) throws IOException,ServletException{
        PrintWriter out=response.getWriter();
        response.setContentType("text/html");

        String accno=request.getParameter("ACCNO");   

        // int mobile=Integer.parseInt(mob);
        String mone=request.getParameter("MONEY");
        int money=Integer.parseInt(mone);

        out.print("<div style='background-color:black'<br>");
            out.print("<img src='img/1.jpg' border=12 width=400px alt='IMG not found' align=left>");
            out.print("<h1 align=center><font size='8' color=white><b>APANA-BANK</b></font><br><font color=white><i>extraordinary bank</i></font></h1>");
            out.print("<br><br><br><br><br>");
            out.print("</div>");
            out.print("</head>");
            out.print("<body>");
            out.print("<div style='background-color:black'>");
            out.print("<table align=center>");
            
            out.print("<tr></tr><tr></tr>");
            
            out.print("<tr><td width=18%><a href=create.html style='text-decoration: none;'><font size='4' color=white>NEW ACCOUNT</font></a></td>");
            out.print("<td width=18%><a href=balance.html style='text-decoration: none;'><font size='4' color=white>BALANCE</font></a></td>");
            out.print("<td width=18%><a href=deposit.html style='text-decoration: none;'><font size='4' color=white>DEPOSIT</font></a></td>");
            out.print("<td width=18%><a href=withdraw.html style='text-decoration: none;'><font size='4' color=white>WITHDRAW</font></a></td>");
            out.print("<td width=18%><a href=transfer.html style='text-decoration: none;'><font size='4' color=white>TRANSFER</font></a></td>");
            out.print("<td width=18%><a href=close.jsp style='text-decoration: none;''><font size='4' color=white>CLOSE A/C</font></a></td>");
                
                //<!-- <td><a href=create.jsp style="text-decoration: none;"><font size='4' color=white>NEW ACCOUNT</font></a></td> -->
            out.print("</tr><tr></tr><tr></tr>");
            out.print("</table><br><br></div>");

    }
}