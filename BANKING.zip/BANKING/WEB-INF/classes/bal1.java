import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class bal1 extends HttpServlet{
    public void service(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException{

        String accno=request.getParameter("ACCNO");

        PrintWriter out=response.getWriter();
        response.setContentType("text/html");
        try{
            
        out.print("<div style='background-color:black'<br>");
        out.print("<img src='img/1.jpg' border=12 width=400px alt='IMG not found' align=left>");
        out.print("<h1 align=center><font size='8' color=white><b>APANA-BANK</b></font><br><font color=white><i>extraordinary bank</i></font></h1>");
        out.print("<br><br><br><br><br>");
        out.print("</div>");
        out.print("</head>");
        out.print("<body>");
        out.print("<div style='background-color:black'>");
        out.print("<table align=center>");
        
        out.print("<tr></tr><tr></tr>");
        
        out.print("<tr><td width=18%><a href=create.html style='text-decoration: none;'><font size='4' color=white>NEW ACCOUNT</font></a></td>");
        out.print("<td width=18%><a href=balance.html style='text-decoration: none;'><font size='4' color=white>BALANCE</font></a></td>");
        out.print("<td width=18%><a href=deposit.html style='text-decoration: none;'><font size='4' color=white>DEPOSIT</font></a></td>");
        out.print("<td width=18%><a href=withdraw.html style='text-decoration: none;'><font size='4' color=white>WITHDRAW</font></a></td>");
        out.print("<td width=18%><a href=transfer.html style='text-decoration: none;'><font size='4' color=white>TRANSFER</font></a></td>");
        out.print("<td width=18%><a href=close.jsp style='text-decoration: none;''><font size='4' color=white>CLOSE A/C</font></a></td>");
            
            //<!-- <td><a href=create.jsp style="text-decoration: none;"><font size='4' color=white>NEW ACCOUNT</font></a></td> -->
        out.print("</tr><tr></tr><tr></tr>");
        out.print("</table><br><br></div>");



            Class.forName("oracle.jdbc.driver.OracleDriver");
            
            Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","sys as sysdba","anand");

            Statement st=con.createStatement();

            ResultSet rs=st.executeQuery("select * from bank where accno="+accno);

            ResultSetMetaData rsmd=rs.getMetaData();
            int nc=rsmd.getColumnCount();

            out.print("<div>");
            out.print("<table>");
            while(rs.next()){
                for(int c=1;c<nc;c++){
                    
                    out.print("<tr></tr>");
                    out.print("<tr><td>"+rsmd.getColumnName(c)+"</td>"+rs.getString(c)+"<td></td></tr>");
                }
            }
            out.print("</table>");
            out.print("</div");
        }
        catch(Exception e){
            System.out.println("404 ERROR FOUND");
        }
    }
}