import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.io.*;

public class accountinfo extends HttpServlet{
    public void service(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException{

        PrintWriter out=response.getWriter();
        response.setContentType("text/html");

        String mobile=request.getParameter("MOBILE");
        String password=request.getParameter("PASSWORD");

        try{
            Class.forName("oracle.jdbc.driver.OracleDriver");

            Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","sys as sysdba","anand");

            Statement st=con.createStatement();

           ResultSet rs=st.executeQuery("select mobile,password from bank");

           ResultSetMetaData rsmd=rs.getMetaData();
           int nc=rsmd.getColumnCount();

           while(rs.next()){
             for(int c=1;c<=nc;c++){
                 if(rs.getString(1).equals(mobile)||rs.getString(2).equals(password))
                 response.sendRedirect("/info.com");
             }
           }
           response.sendRedirect("accountinfo.jsp?STATUS=invalid mobile number/password");
            
            
        }
        catch(Exception e){
            System.out.println("error in database"+e);
        }
    }
}