import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class deposit extends HttpServlet
{
    public void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException{

        //boolean t=false;
        PrintWriter out=response.getWriter();
        response.setContentType("text/html");

        String accno=request.getParameter("ACCNO");   

        // int mobile=Integer.parseInt(mob);
        String mone=request.getParameter("MONEY");
        int money=Integer.parseInt(mone);
        


        try{

            ServletContext sc = getServletContext();

            Class.forName("oracle.jdbc.driver.OracleDriver");
    
            Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","sys as sysdba","anand");

            Statement st=con.createStatement();
            
            PreparedStatement pst=con.prepareStatement("update bank set amount=amount+"+money +"where accno="+accno);

            int i=pst.executeUpdate();
            // update bank set amount=amount+"+money +"where accno="+accno
            // out.print("<h3>"+accno+"</h3>");
            // out.print("<h3>"+money+"</h3>");
            
            
            if(i==1){
                response.sendRedirect("deposit2.jsp?STATUS="+money+" is deposited to "+accno+" account number");
            }

            else{
                
                response.sendRedirect("deposit.html");
            }  
       
            
             
           
        
        }
    
        catch(Exception se){
            out.print("<h1>404 ERROR FOUND"+se+"</h1>");
        }

        out.print("</body>");
        out.print("</html>");
        
        out.close();
    }
}
