import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class withdraw1 extends HttpServlet{
    public void service(HttpServletRequest request,HttpServletResponse response) throws IOException,ServletException{
        
        PrintWriter out=response.getWriter();
        response.setContentType("text/html");
        //String acc=request.getParameter("ac");
        String am=request.getParameter("AMOUNT");
        //String acc=(String)session.getAttribute("ACC");
        Cookie[] c=request.getCookies(); 
        
        String acc=c[1].getValue();
        out.print(acc);
        //String bal="anand";
        String bal=c[1].getValue();
        Cookie b1=new Cookie("BAL",bal);
        Cookie b2=new Cookie("ACC",acc);
        //out.print("anand");
        response.addCookie(b1);
        response.addCookie(b2);
        
        
        //out.print(acc);
        //response.sendRedirect("withdraw1.jsp");
        // try{
        //     Class.forName("oracle.jdbc.driver.OracleDriver");
        //     Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","sys as sysdba","anand");

        //     PreparedStatement pst=con.prepareStatement("update bank set amount=amount-"+am);

        //     int i=pst.executeUpdate();

        //         Statement st=con.createStatement();
        //         ResultSet rs=st.executeQuery("select amount from bank where accno="+acc);
        //         rs.next();
        //         out.print(rs.getString(1));  
        //         Cookie b=new Cookie("BAL",rs.getString(1));
        //         response.addCookie(b);
        //         Cookie ac=new Cookie("ACC",acc);
        //         response.addCookie(ac);
        //         response.sendRedirect("withdraw1.jsp");
            
        // }
        // catch(Exception e){
        //     System.out.println("404 ERROR FOUND"+e);
        // }
    }
}