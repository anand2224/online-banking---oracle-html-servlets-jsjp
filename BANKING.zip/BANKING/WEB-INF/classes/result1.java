import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;


public class result1 extends HttpServlet{
    public void service(ServletRequest request,ServletResponse response) throws IOException,ServletException{


        java.util.Date ud=new java.util.Date();
        java.sql.Date sd=new java.sql.Date(ud.getTime());

        java.text.SimpleDateFormat sdf=new java.text.SimpleDateFormat("dd-MMM-yyyy");


        String dat=sdf.format(sd);


        PrintWriter out=response.getWriter();
        response.setContentType("text/html");

        String nam=request.getParameter("NAME");
        String name=nam.toUpperCase();
        //String password=request.getParameter("PW1");
        String amoun=request.getParameter("AMOUNT");       int amount=Integer.parseInt(amoun);
        String add=request.getParameter("ADDRESS");
        String address=add.toUpperCase();
        String mobile=request.getParameter("MOBILE");         
        out.print("<h1>welcome to the world</h1>");
        
        String accno=91+mobile;
        //int accno=Integer.parseInt(acc);

        try{

            
            Class.forName("oracle.jdbc.driver.OracleDriver");
    
            Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","sys as sysdba","anand");

            Statement st= con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);

            ResultSet rs= st.executeQuery("SELECT mobile From bank");
        
        PreparedStatement pst=con.prepareStatement("insert into bank values(?,?,?,?,?,?)");
             pst.setString(1,accno);
             pst.setString(2,name);
             pst.setInt(3,amount);
             pst.setString(4,address);
             pst.setString(5,mobile);
             pst.setString(6,dat);
             int i=pst.executeUpdate();

            if(i==1)
            {
            out.print("<div style='background-color:black'<br>");
            out.print("<img src='img/1.jpg' border=12 width=400px alt='IMG not found' align=left>");
            out.print("<h1 align=center><font size='8' color=white><b>APANA-BANK</b></font><br><font color=white><i>extraordinary bank</i></font></h1>");
            out.print("<br><br><br><br><br>");
            out.print("</div>");
            out.print("</head>");
            out.print("<body>");
            out.print("<div style='background-color:black'>");
            out.print("<table align=center>");
            
            out.print("<tr></tr><tr></tr>");
            
            out.print("<tr><td width=18%><a href=create.html style='text-decoration: none;'><font size='4' color=white>NEW ACCOUNT</font></a></td>");
            out.print("<td width=18%><a href=balance.html style='text-decoration: none;'><font size='4' color=white>BALANCE</font></a></td>");
            out.print("<td width=18%><a href=deposit.html style='text-decoration: none;'><font size='4' color=white>DEPOSIT</font></a></td>");
            out.print("<td width=18%><a href=withdraw.html style='text-decoration: none;'><font size='4' color=white>WITHDRAW</font></a></td>");
            out.print("<td width=18%><a href=transfer.html style='text-decoration: none;'><font size='4' color=white>TRANSFER</font></a></td>");
            out.print("<td width=18%><a href=close.jsp style='text-decoration: none;''><font size='4' color=white>CLOSE A/C</font></a></td>");
                
                //<!-- <td><a href=create.jsp style="text-decoration: none;"><font size='4' color=white>NEW ACCOUNT</font></a></td> -->
            out.print("</tr><tr></tr><tr></tr>");
            out.print("</table><br><br></div>");

            out.print("<table align=center>");
            out.print("<tr></tr>");
            out.print("<tr>");
            //out.print("<th></th>");
            out.print("<th><h1>ACCOUNT INFO</h1></th>");

            out.print("</tr>");
            out.print("</table>");
            out.print("<table align=center>");
            out.print("<tr>");
            out.print("<td><h3>ACC NO:"+accno+"</h3></td>");
            out.print("</tr>");
            out.print("<tr>");
            out.print("<td><h3>NAME :"+name+"</h3></td");
            out.print("</tr>");
            out.print("<tr></tr>");
            out.print("<tr>");
            out.print("<td><h3>AMOUNT :"+amount+"</h3></td");
            out.print("</tr>");
            out.print("<tr></tr>");
            out.print("<tr>");
            out.print("<td><h3>ADDRESS :"+address+"</h3></td");
            out.print("</tr>");
            out.print("<tr></tr>");
            out.print("<tr>");
            out.print("<td><h3>MOBILE :"+mobile+"</h3></td");
            out.print("</tr>");
            out.print("<tr>");
            out.print("<td><a href=banking.html style='text-decoration: none;'><font size='4' color=white><button>OK</button></font></a></td>");
            out.print("</tr>");
            out.print("</table>");

            out.print("</body");

            }

         
        }

        catch(Exception e){
                out.print("result1.java"+e);
        }
    }
}