import java.sql.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class close extends HttpServlet{
    public void service(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException {
        
        String accno=request.getParameter("ACC");

        PrintWriter out=response.getWriter();
        response.setContentType("text/html");

        

        

        try{

            Class.forName("oracle.jdbc.driver.OracleDriver");

            Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","sys as sysdba","anand");

            Statement st=con.createStatement();
            
            ResultSet rs=st.executeQuery("select accno from bank");

            ResultSetMetaData rsmd=rs.getMetaData();
            
            int nc=rsmd.getColumnCount();

            while(rs.next()){
                for(int i=1;i<=nc;i++){
                    if(rs.getString(1).equals(accno))

                    {PreparedStatement pst=con.prepareStatement("delete from bank where accno="+accno);

                    int c=pst.executeUpdate();
                    response.sendRedirect("close.jsp?STATUS= account is deleted successfully");}
                }
            }

            
            response.sendRedirect("close.jsp?STATUS=ACCNO doesnot exist");

            
            

        
            
        }
        catch(Exception e){
            System.out.println("404 error found"+e);
        }
        
    }
}
