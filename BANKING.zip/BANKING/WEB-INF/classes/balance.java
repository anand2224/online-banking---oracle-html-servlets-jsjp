import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.io.*;

public class balance extends HttpServlet{
    public void service(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException{

        PrintWriter out=response.getWriter();
        response.setContentType("text/html");

        String accno=request.getParameter("ACCNO");
        //String password=request.getParameter("PASSWORD");

        ServletContext sc=getServletContext();

        try{
            Class.forName("oracle.jdbc.driver.OracleDriver");

            Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","sys as sysdba","anand");

            Statement st=con.createStatement();

           ResultSet rs=st.executeQuery("select accno from bank");

           ResultSetMetaData rsmd=rs.getMetaData();
           int nc=rsmd.getColumnCount();

           while(rs.next()){
             for(int c=1;c<=nc;c++){
                 if(rs.getString(1).equals(accno))
                    response.sendRedirect("balance1.jsp?STATUS="+accno);
             }
           }
           response.sendRedirect("balance.jsp?STATUS=account number doesnot exist");
            
            
        }
        catch(Exception e){
            System.out.println("error in database"+e);
        }
    }
}