import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class create extends HttpServlet
{
    public void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException{

        //boolean t=false;
        PrintWriter out=response.getWriter();
        response.setContentType("text/html");

        String mobile=request.getParameter("MOBILE");   

        // int mobile=Integer.parseInt(mob);

        


        try{

            ServletContext sc = getServletContext();

            Class.forName("oracle.jdbc.driver.OracleDriver");
    
            Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","sys as sysdba","anand");

            Statement st=con.createStatement();
            ResultSet rs= st.executeQuery("SELECT mobile From bank");
        
            ResultSetMetaData rsmd=rs.getMetaData();
            int nc=rsmd.getColumnCount();

            // response.sendRedirect("create.jsp?STATUS=*mobile number already registered");
            while(rs.next()){
                for(int c=1;c<=nc;c++){
                if(rs.getString(1).equals(mobile)) response.sendRedirect("create.jsp?STATUS=*mobile number already registered");   
                }
            }
       
            
             
            RequestDispatcher rd=sc.getRequestDispatcher("/result.com");
            rd.forward(request,response);

            

            // PreparedStatement pst=con.prepareStatement("insert into bank values(?,?,?,?)");
            //     pst.setString(1,name);
            //     pst.setString(2,password);
            //     pst.setInt(3,amount);
            //     pst.setString(4,address);
            //     int i=pst.executeUpdate();


        
        }
    
        catch(Exception se){
            out.print("<h1>404 ERROR FOUND"+se+"</h1>");
        }

        out.print("</body>");
        out.print("</html>");
        
        out.close();
    }
}